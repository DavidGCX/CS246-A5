// Code taken from horseracing example
#include "observer.h"

Observer::~Observer() {}

