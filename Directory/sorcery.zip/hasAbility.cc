#include "hasAbility.h"

CanUseAbility::~CanUseAbility(){}
